export function registerAacEncoder(): void;
